"""Isolated integration tests; run with pytest -q test_living_world.py."""
import os,tempfile,importlib
from fastapi.testclient import TestClient

def test_sandbox_clock_canon_snapshot():
 with tempfile.TemporaryDirectory() as tmp:
  os.environ.update(VYBE_DATA_DIR=tmp,VYBE_PASSWORD='test-only-secret',VYBE_SESSION_SECRET='test-session-secret',VYBE_WORKER='0')
  import server
  importlib.reload(server)
  with TestClient(server.app) as client:
   assert client.get('/api/state').status_code==401
   assert client.post('/api/login',json={'password':'test-only-secret'}).status_code==200
   state=client.get('/api/state').json()
   assert state['story_mode']=='sandbox' and state['paused']
   assert len(state['schedule'])>100
   event={'event_id':'test-001','event_type':'campus_notice','summary':'Sandbox test only','participants':[]}
   assert client.post('/api/director/canon-events',json=event).json()['canon_status']=='sandbox'
   assert client.post('/api/director/canon-events',json=event).status_code==409
   assert client.post('/api/director/canon-events/test-001/approve').status_code==409
   assert client.post('/api/director/canon-events/test-001/promote').status_code==200
   assert client.post('/api/director/canon-events/test-001/approve').status_code==200
   assert len(client.get('/api/director/canon-export').json()['events'])==1
   assert client.post('/api/director/snapshot').status_code==200
   assert client.post('/api/clock',json={'speed':5}).status_code==400
   assert client.post('/api/director/story-mode',json={'activate':True}).json()['paused']
